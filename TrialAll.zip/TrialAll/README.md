# TrialAll

This app includes basic examples of using fingerprint sensor on mobile, Usages of swipe to load more, swipe to refresh, swipe 
to delete and two examples of View model.
