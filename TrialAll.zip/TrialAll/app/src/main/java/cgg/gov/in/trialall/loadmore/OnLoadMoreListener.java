package cgg.gov.in.trialall.loadmore;

public interface OnLoadMoreListener {
    void onLoadMore();
}