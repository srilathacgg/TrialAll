package cgg.gov.in.trialall.viewmodel2;

/**
 * Created by user on 19-02-2019.
 */

public interface VideoInterface {
    void sendVideoPath(String position);
}
